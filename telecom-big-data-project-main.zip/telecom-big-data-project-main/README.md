# Telecom Big Data Analytics Platform

A Big Data platform for analyzing telecom data such as Call Detail Records (CDR), internet usage, SMS, recharge transactions, customer usage, network KPIs, and complaints.

## Project Pipeline

### Batch Processing

CSV / Dataset
↓
Kafka
↓
HDFS
↓
Spark
↓
Hive
↓
Power BI

### Real-Time Analytics

Kafka
↓
Spark Streaming
↓
HBase

## Main Technologies

- Apache Kafka
- Apache Hadoop / HDFS
- Apache YARN
- Apache Spark / PySpark
- Apache Hive
- Apache HBase
- ClickHouse
- Power BI
- Python
- Tailscale
- GitHub

## Data Fields

The telecom records contain:

- Customer_ID
- Date
- Time
- Cell_ID
- msisdn
- Call_Duration
- Data_Usage
- SMS_Count
- Recharge_Amount
- Package

## Team

- Eiad — Team Leader / Infrastructure / Hadoop / HDFS / YARN
- Gana — Kafka / Data Ingestion
- Vereena — Spark / PySpark / Streaming
- Nour — Hive / HBase / Power BI

## Project Goals

The platform will be used to analyze:

- Top customers by usage
- Most active cells
- Peak hours
- Average call duration
- Data consumption
- Revenue per package
- Customer segmentation
- Suspicious usage

## Repository Structure

```text
telecom-big-data-project/
│
├── generate_telecom_data.py
├── kafka_producer.py
├── kafka_producer_realtime.py
├── data/
├── spark/
├── hdfs/
├── hive/
├── hbase/
├── powerbi/
└── README.md
